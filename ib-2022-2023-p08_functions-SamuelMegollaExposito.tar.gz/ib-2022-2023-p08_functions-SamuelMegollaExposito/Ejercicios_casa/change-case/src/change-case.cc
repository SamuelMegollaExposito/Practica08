/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 * @author Samuel Megolla Expósito
 * @date Nov 23, 2022
 * @brief Recibe
 */
#include<iostream>
#include<cctype>
#include<string>

using namespace std;

string Transforms(string texto);


int main(){
	string texto{};
	cin>>texto;
	cout<<Transforms(texto)<<endl;	

return 0;
}

string Transforms(string texto){

	int length = texto.length();
	for(int i = 0; i<=length-1; i++){
		if(texto[i] >='a' && texto[i] <='z'){
			texto[i] = toupper(texto[i]);

		}else{
			texto[i] = tolower(texto[i]);
		}
	}

return texto;
}
