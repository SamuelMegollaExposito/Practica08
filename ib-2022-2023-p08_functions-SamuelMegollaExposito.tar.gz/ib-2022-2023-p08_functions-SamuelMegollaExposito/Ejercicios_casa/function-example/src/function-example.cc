/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Samuel Megolla Expósito alu0101567198@ull.edu.es
  * @date Oct 18 noviembre
  * @brief El programa realizara el calculo matematico de la siguiente funcion sqrt(2t-4)/x²-y²
  * @bug There are no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */

#include<iostream>
#include<math.h>
#include"function_pow.h"

using namespace std;

//publics var
	double resutl{0};
	double var1{0};
	double var2{0};
	double var3{0};

int main(){

	cin>>var1;
	cin>>var2;
	cin>>var3;

	cout<<CalcFun(var1,var2,var3)<<endl;



return 0;
}
