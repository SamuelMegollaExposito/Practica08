#include<math.h>
#include<iostream>

double CalcFun(double var1,double var2, double var3){


        while(var1==var2){
		std::cin>>var1;
		std::cin>>var2;
        }

	var1= sqrt(2*(var3)-4)/pow(var2,2)-pow(var1,2);

	return var1;


}

