double CalcFun(double var1, double var2, double var3);
