/*
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 * @author Samuel Megolla 
 * @date 23.nov.2022
 * @brief El programa recibe como parametros dos numeros naturales (n,m) tales que n>m
 */

#include<iostream>
#include<stdlib.h>

using namespace std;

void GoodArgument(int number1, int number2);
int RandomNumber(int number1, int number2);

int main(){
	 int number1{0},number2{0};
	 cin>>number1>>number2;
	 GoodArgument(number1,number2);	
	cout<<RandomNumber(number1,number2)<<endl;
		    return 0;
}

void GoodArgument(int number1, int number2){
	    if(number1>number2){
		             cout<<"Error: El primer número debe ser menor que el segundo."<<endl;
			         }
}
int RandomNumber(int number1, int number2){
	
	return number1 + rand()%number2;

}
