/*
 *Universidad De La Laguna
 *Grado en Ingenieria Informatica
 *author Samuel Megolla Expósito
 *@brief: El programa calculara el area de un triangulo atraves de la formula
 *de Herons, para esto leera la entrada de sus lados solicisitado por el usuario.
 *en caso de datos erroneos se imprimira en pantalla una alerta de error.
 *
 * */



#include<iostream>
#include<math.h>

using namespace std;

float HeronsForm(float a, float b, float c);
void IsAValidTriangle(float  a, float b, float c);
int main(){

	float a{0},b{0},c{0},s{0};
	cin>>a>>b>>c;
	IsAValidTriangle(a,b,c);
	cout<<HeronsForm(a,b,c)<<endl;

return 0;}

void IsAValidTriangle(float a, float b, float c){

	if(a>b+c || b>a+c || c>a+b){
		cout<<"Not a Valid Triangle"<<endl;
	}
}
float HeronsForm(float a, float b, float c){
	float s = (a+b+c)/2;
	float herons=sqrt(s*(s-a)*(s-b)*(s-c));

return herons;
}
