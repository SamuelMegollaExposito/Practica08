/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Samuel Megolla Exposito
 * @date Nov 23, 2022
 * @brief Recibe un numero n y devulve los factoriales hasta dicho numero
 */

#include<iostream>

using namespace std;

int factorial(int n);
/*
int main(){
        
        int n;
        while cin>>n{
        cout<<int factorial(int n)<<endl;
        }
return 0;
}*/

int factorial(int n){

        int total=1;
        for(int i = 1; i<=n;i++){
        total*=i;
        }
return total;
}

