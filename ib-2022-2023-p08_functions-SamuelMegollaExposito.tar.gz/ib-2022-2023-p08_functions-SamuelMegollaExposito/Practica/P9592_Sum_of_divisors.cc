#include<iostream>

using namespace std;

int sum_divisors(int x);
int sum_divisors(int x){
	
	int suma=0;
	for(int i =0; i<=x; i++){
		if(x%i==0){
		suma+=i
		}
	}
return suma;
}
